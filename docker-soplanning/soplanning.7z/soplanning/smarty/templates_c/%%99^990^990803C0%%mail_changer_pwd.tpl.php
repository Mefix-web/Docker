<?php /* Smarty version 2.6.29, created on 2016-04-28 17:06:53
         compiled from mail_changer_pwd.tpl */ ?>

<?php echo $this->_config[0]['vars']['mail_corps_changerPwd']; ?>
 : 
<?php echo $this->_tpl_vars['lien']; ?>