<?php /* Smarty version 2.6.29, created on 2016-05-01 22:06:49
         compiled from www_change_password.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'escape', 'www_change_password.tpl', 9, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "www_header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<br /><br /><br /><br />

<table align="center" cellpadding="0" cellspacing="0" width="450" class="blocHomepage">
<tr>
	<td align="center" style="padding-bottom:16px;">
		<?php if (@CONFIG_SOPLANNING_TITLE != 'SOPlanning'): ?>
			<span style="font-size:23px;font-weight:bold;"><?php echo ((is_array($_tmp=((is_array($_tmp=@CONFIG_SOPLANNING_TITLE)) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')))) ? $this->_run_mod_handler('escape', true, $_tmp, 'javascript') : smarty_modifier_escape($_tmp, 'javascript')); ?>
</span>
		<?php else: ?>
			<img src="assets/img/pictos/logo.jpg" border="0">
		<?php endif; ?>

		<?php if (isset ( $this->_tpl_vars['planningVersion'] )): ?>
		v<?php echo $this->_tpl_vars['planningVersion']; ?>

		<?php endif; ?>
	</td>
</tr>
</table>

<br /><br /><br />
<table align="center" cellpadding="0" cellspacing="0" width="450" class="blocHomepage">
<tr>
	<td align="center" style="padding-bottom:16px;">
		<table width="300" align="center">
			<tr>
				<td align="right"><b><?php echo $this->_config[0]['vars']['login_login']; ?>
 :</b></td>
				<td><?php echo $this->_tpl_vars['userTmp']['login']; ?>
</td>
			</tr>
			<tr>
				<td class="normal" align="right"><b><?php echo $this->_config[0]['vars']['rappelPwdNouveauPassword']; ?>
 :</b></td>

				<td><input type="password" size="20" id="password"></td>
			</tr>
			<tr>
				<td>
					&nbsp;
				</td>
				<td>
					<input class="normal" type="submit" value="GO" style="width:40px;" onClick="xajax_nouveauPwd($('password').value);undefined;">
				</td>
			</tr>
		</table>
	</td>
</tr>
</table>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "www_footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>