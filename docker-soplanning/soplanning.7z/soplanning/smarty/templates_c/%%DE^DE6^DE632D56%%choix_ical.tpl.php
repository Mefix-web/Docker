<?php /* Smarty version 2.6.29, created on 2016-04-28 17:37:14
         compiled from choix_ical.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'escape', 'choix_ical.tpl', 37, false),)), $this); ?>

<form class="form-horizontal" id="formIcal">
	<div class="control-group">
		<label class="control-label"><?php echo $this->_config[0]['vars']['icalExport_users']; ?>
 :</label>
		<div class="controls">
			<input type="radio" name="ical_users" id="ical_users_moi" value="ical_users_moi" checked="checked" style="margin-top:0px" onClick="xajax_icalGenererLien(getRadioValue('ical_users'), getRadioValue('ical_projets'), getCheckboxes('formIcal', 'icalProjetsChoix'));">
			<label style="display:inline" for="ical_users_moi"><?php echo $this->_config[0]['vars']['icalExport_users_moi']; ?>
</label>
			<br>
			<input type="radio" name="ical_users" id="ical_users_tous" value="ical_users_tous" style="margin-top:0px" onClick="xajax_icalGenererLien(getRadioValue('ical_users'), getRadioValue('ical_projets'), getCheckboxes('formIcal', 'icalProjetsChoix'));">
			<label style="display:inline" for="ical_users_tous"><?php echo $this->_config[0]['vars']['icalExport_users_tous']; ?>
</label>
			<br><br>
		</div>
	</div>
	<div class="control-group">
		<label class="control-label"><?php echo $this->_config[0]['vars']['icalExport_projets']; ?>
 :</label>
		<div class="controls">
			<input type="radio" name="ical_projets" id="ical_projets_tous" value="ical_projets_tous" checked="checked" onClick="$('divIcalProjets').style.display='none';" style="margin-top:0px" onClick="xajax_icalGenererLien(getRadioValue('ical_users'), getRadioValue('ical_projets'), getCheckboxes('formIcal', 'icalProjetsChoix'));">
			<label style="display:inline" for="ical_projets_tous"><?php echo $this->_config[0]['vars']['icalExport_projets_tous']; ?>
</label>
			<br>
			<input type="radio" name="ical_projets" id="ical_projets_liste" value="ical_projets_liste" style="margin-top:0px" onClick="$('divIcalProjets').style.display='block';xajax_icalGenererLien(getRadioValue('ical_users'), getRadioValue('ical_projets'), getCheckboxes('formIcal', 'icalProjetsChoix'));">
			<label style="display:inline" for="ical_projets_liste"><?php echo $this->_config[0]['vars']['icalExport_projets_liste']; ?>
</label>
			<div id="divIcalProjets" style="display:none">
				<br>
				<?php $_from = $this->_tpl_vars['listeProjets']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['projet']):
?>
					<input type="checkbox" style="margin-top:0px" id="icalProjetsChoix_<?php echo $this->_tpl_vars['projet']['projet_id']; ?>
", value="<?php echo $this->_tpl_vars['projet']['projet_id']; ?>
" onClick="xajax_icalGenererLien(getRadioValue('ical_users'), getRadioValue('ical_projets'), getCheckboxes('formIcal', 'icalProjetsChoix'));"><label style="display:inline" for="icalProjetsChoix_<?php echo $this->_tpl_vars['projet']['projet_id']; ?>
"><?php echo $this->_tpl_vars['projet']['nom']; ?>
 (<?php echo $this->_tpl_vars['projet']['projet_id']; ?>
)</label>
					<br>
				<?php endforeach; endif; unset($_from); ?>
			</div>
			<br><br>
		</div>
	</div>
	<div class="control-group">
		<label class="control-label"><?php echo $this->_config[0]['vars']['icalExport_url']; ?>
 :</label>
		<div class="controls">
			<input type="text" id="inputLienIcal" value="<?php echo $this->_tpl_vars['lienIcal']; ?>
" style="width:270px">
			&nbsp;<a href="#" onmouseover="return coolTip('<?php echo ((is_array($_tmp=$this->_config[0]['vars']['ical_instructions'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'quotes') : smarty_modifier_escape($_tmp, 'quotes')); ?>
', WIDTH, 270)"  onmouseout="nd()" href="javascript:undefined;"><i class="icon-question-sign"></i></a>
			<br><br>
		</div>
	</div>
	<div class="control-group">
		<label class="control-label"><?php echo $this->_config[0]['vars']['icalExport_download']; ?>
 :</label>
		<div class="controls">
			<a href="export_ical.php"><img src="assets/img/pictos/download.png" width="20" height="20" border="0" /></a>
			&nbsp;<a href="#" onmouseover="return coolTip('<?php echo $this->_config[0]['vars']['ical_instructions2']; ?>
', WIDTH, 270)"  onmouseout="nd()" href="javascript:undefined;"><i class="icon-question-sign"></i></a>
		</div>
	</div>
</form>