<?php
require('./base.inc');
require(BASE . '/../config.inc');

#error_reporting(E_ALL ^ E_NOTICE);  
#$conn = new mysqli('127.0.0.1', 'soplanning', 'soplanning', 'soplanning');
$conn = new mysqli($cfgHostname, $cfgUsername,  $cfgPassword, $cfgDatabase);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

// if(isset($_GET['ds']) && isset($_GET['de'])){
//   $date_start = 
//   $date_end   = $_GET['de'];
// } else {
  
// }

$date_start = $_GET['ds'] ? $_GET['ds'] : "2022-12-01";
$date_end   = $_GET['de'] ? $_GET['de'] : "2022-12-31";

$dateStart = new DateTime();
$dateEnd   = new DateTime();
$dateStart->setDate(substr($date_start,0,4), substr($date_start,5,2), substr($date_start,8,2));
$dateEnd  ->setDate(substr($date_end  ,0,4), substr($date_end  ,5,2), substr($date_end  ,8,2));

// echo "<br>";
// echo $dateStart->format('Y-m-d') ;
// echo "<br>";
// echo substr($date_start,5,2);
// echo "<br>";
// echo substr($date_start,8,2);
// echo "<br>";
// var_dump($dateEnd);
// echo "<br>";


?>
<form
echo "Date start: <input type='date' value='".$dateStart->format('Y-m-d')."'><br>";
echo "Date end: <input type='date' value='".$dateEnd->format('Y-m-d')."'><br>";
echo "<br>";

// $sql = "SELECT *
// FROM   `planning_periode`
// WHERE  `projet_id` = 'Leave'
//        AND `date_debut` >= '".$date_start."'
//        AND `date_fin` <= '".$date_end."'
// ORDER  BY `projet_id`";


// $sql .= "WHERE (
//   (pd.date_debut <= '" . $dateStart->format('Y-m-d') . "'
//   AND pd.date_fin >= '" . $dateStart->format('Y-m-d') . "')
//   OR
//   (pd.date_debut <= '" . $dateEnd->format('Y-m-d') . "'
//   AND pd.date_debut >= '" . $dateStart->format('Y-m-d') . "')
// )";
$sql = "SELECT * FROM   `planning_periode`
WHERE (
  (date_debut <= '" . $dateStart->format('Y-m-d') . "'
  AND date_fin >= '" . $dateStart->format('Y-m-d') . "')
  OR
  (date_debut <= '" . $dateEnd->format('Y-m-d') . "'
  AND date_debut >= '" . $dateStart->format('Y-m-d') . "')
)
  AND
  `projet_id` = 'Leave'
ORDER BY `date_debut`";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='1'>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    // var_dump($row);
    echo "<tr><td>ID: ".$row["periode_id"]."</td><td>UserID: ".$row["user_id"]."</td><td>Start: ".$row["date_debut"]."</td><td>End: ".$row["date_fin"]."</td><td>Duration: ".$row["duree"]."</td></tr>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>
</table>
<hr>
<?php
/*


# Verlofdagen
 SELECT *
FROM `planning_periode`
WHERE `projet_id` = 'Leave' AND `date_debut` >= '2022-10-01' AND `date_fin` <= '2022-12-31'
ORDER BY `projet_id`
LIMIT 50




# Users zonder verlof
SELECT nom FROM `planning_user`
Where user_id not in (SELECT distinct user_id
FROM `planning_periode`
WHERE `projet_id` = 'Leave' AND `date_debut` >= '2022-10-01' AND `date_fin` <= '2022-12-31'
ORDER BY `projet_id`)
and visible_planning = "oui";

# users met verlof, aantal dagen zonder weekends en feestdagen (planning_ferie)

SELECT distinct user_id, nom
FROM `planning_periode`
left join planning_user using(`user_id`)
WHERE `projet_id` = 'Leave' AND `date_debut` >= '2022-10-01' AND `date_fin` <= '2022-12-31' 


# left join planning_user_groupe

SELECT u.nom as user_name, p.nom as user_group FROM `planning_user` u 
left join planning_user_groupe p on u.user_id = p.user_groupe_id
Where user_id not in (SELECT distinct user_id
FROM `planning_periode`
WHERE `projet_id` = 'Leave' AND `date_debut` >= '2022-10-01' AND `date_fin` <= '2022-12-31'
ORDER BY `projet_id`)
and visible_planning = "oui";
*/
?>