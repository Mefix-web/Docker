<?php
require('./base.inc');
require(BASE . '/../config.inc');

error_reporting(E_ALL ^ E_NOTICE);  

$conn = new mysqli($cfgHostname, $cfgUsername,  $cfgPassword, $cfgDatabase);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

// @TODO: Fill in default dates from this month
$date_start = $_GET['ds'] ? $_GET['ds'] : "2022-12-01";
$date_end   = $_GET['de'] ? $_GET['de'] : "2022-12-31";

$dateStart = new DateTime();
$dateEnd   = new DateTime();
$dateStart->setDate(substr($date_start,0,4), substr($date_start,5,2), substr($date_start,8,2));
$dateEnd  ->setDate(substr($date_end  ,0,4), substr($date_end  ,5,2), substr($date_end  ,8,2));
?>
<h1>Users with leave booked in period from <b>
    <?php echo $dateStart->format('Y-m-d')?>
  </b> to <b>
    <?php echo $dateEnd->format('Y-m-d') ?>
  </b></h1>
<form method="GET" action="<?php echo $_SERVER["PHP_SELF"]?>">
  Date start: <input type='date' name="ds" value='<?php echo $dateStart->format('Y-m-d')?>'><br>
  Date end: <input type='date' name="de" value='<?php echo $dateEnd->format('Y-m-d')?>'><br>
  <input type="submit">
</form>
<br>
<?php
$sql = "SELECT * FROM planning_periode
    LEFT JOIN planning_user ON planning_user.user_id = planning_periode.user_id
    WHERE (
      (`date_debut` <= '" . $dateStart->format('Y-m-d') . "' AND `date_fin` >= '" . $dateStart->format('Y-m-d') . "')
      OR
      (`date_debut` <= '" . $dateEnd->format('Y-m-d') . "' AND `date_debut` >= '" . $dateStart->format('Y-m-d') . "')
    ) AND `projet_id` = 'Leave'
    ORDER BY `date_debut`";

$result = $conn->query($sql);
// echo "<pre>";
if ($result->num_rows > 0) {
  echo "<table border='1'>";
  while($row = $result->fetch_assoc()) {
    // var_dump($row);
    //echo '<tr><td>'.$row['nom'].'</td></tr>';
    echo "<tr>";
        echo "<td>ID: ".$row["periode_id"]."</td>";
        echo "<td>".$row["nom"]." (".$row["user_id"].")</td>";
        echo "<td>Start: ".$row["date_debut"]."</td>";
        echo "<td>End: ".$row["date_fin"]."</td>";
        echo "<td>Duration: ".$row["duree"]."</td>";
    echo "</tr>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>
</table>
<h2>Total:
  <?php echo $result->num_rows; ?>
</h2>
<hr>
<h1>SQL executed</h1>
<pre><?php echo($sql);?></pre>