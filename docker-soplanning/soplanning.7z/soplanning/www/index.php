<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
#ini_set('max_execution_time', '300'); //300 seconds = 5 minutes
#set_time_limit(300);

require_once('./base.inc');
require_once(BASE . '/../config.inc');

// redirection possible vers l'installeur / upgrade
$checkInstall = $version->checkInstall();
if(!$checkInstall) {
	header('Location: ' . BASE . '/install/');
	exit;
}

/* autoconnect if already opened session */
if(isset($_SESSION['user_id']) && $_SESSION['user_id'] != '') {
	$user = New User();
	if($user->db_load(array('user_id', '=', $_SESSION['user_id']))) {
		header('Location: planning.php');
		exit;
	}
}

$smarty = new MySmarty();

// header connect� non inclus sur la page de login, check de version ici
$version = new Version();
$smarty->assign('infoVersion', $version->getVersion());

if(is_file(BASE . '/../alert.txt')) {
	$alerte = file_get_contents(BASE . '/../alert.txt');
	$smarty->assign('alerte', $alerte);
}

$smarty->assign('xajax', $xajax->getJavascript("", "assets/js/xajax.js"));

$smarty->display('www_index.tpl');

?>
